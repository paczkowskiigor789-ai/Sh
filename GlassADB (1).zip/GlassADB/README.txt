Glass ADB - terminal powłoki z integracją Shizuku
1. Rozpakuj ZIP, w AndroidIDE: Open project -> wybierz folder GlassADB.
2. Poczekaj na synchronizację Gradle (pierwszy raz pobiera zależności z internetu).
3. Build -> Build APK (debug), zainstaluj wynik.
4. Uruchom Shizuku, w Glass ADB dotknij etykiety statusu i nadaj zgodę.
Alternatywa: wrzuć folder na GitHub - workflow w .github/workflows zbuduje APK.
