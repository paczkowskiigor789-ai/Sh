package com.example.glassadb

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShellRunner {

    /** Czy usługa Shizuku działa (binder żyje). */
    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) {
        false
    }

    /** Czy Shizuku działa ORAZ aplikacja ma zgodę. */
    fun ready(): Boolean = try {
        Shizuku.pingBinder() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) {
        false
    }

    /**
     * Startuje komendę. Z Shizuku: powłoka z uprawnieniami ADB (shell).
     * Bez Shizuku: zwykła powłoka z uprawnieniami tej aplikacji (bezpieczny tryb lokalny).
     */
    fun start(command: String, viaShizuku: Boolean): Process {
        val argv = arrayOf("sh", "-c", command)
        return if (viaShizuku) {
            // Shizuku.newProcess jest w API 13 prywatne - wywołujemy refleksją.
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            m.invoke(null, argv, null, null) as Process
        } else {
            ProcessBuilder(*argv).start()
        }
    }
}
