package com.example.glassadb

import android.animation.AnimatorSet
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import rikka.shizuku.Shizuku
import java.io.InputStream
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private companion object {
        const val REQ_SHIZUKU = 100
        const val TIMEOUT_S = 60L
        val C_OUT = 0xFFEAF0FF.toInt()
        val C_ERR = 0xFFFF8A8A.toInt()
        val C_PROMPT = 0xFF7CF2D8.toInt()
        val C_INFO = 0xFF9FB0D6.toInt()
        val RISKY = Regex(
            """(^|[\s;&|])(rm|mkfs|dd|wipe|flash)\b|factory|reboot\s+(bootloader|recovery|fastboot)|pm\s+(uninstall|clear)|format"""
        )
        val QUICK = listOf(
            "pm list packages -3", "getprop ro.product.model", "dumpsys battery",
            "wm size", "df -h", "id", "settings list system"
        )
    }

    private lateinit var content: View
    private lateinit var chipsScroll: View
    private lateinit var chips: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var outputView: TextView
    private lateinit var input: EditText
    private lateinit var runBtn: TextView
    private lateinit var statusDot: View
    private lateinit var statusText: TextView

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    private val out = SpannableStringBuilder()
    private val recent = mutableListOf<String>()
    private val animators = mutableListOf<AnimatorSet>()

    @Volatile private var current: Process? = null
    private var running = false
    private var flushScheduled = false
    private var dotColor = Color.GRAY
    private var announcedLocal = false

    private val onBinder = Shizuku.OnBinderReceivedListener { updateStatus() }
    private val onDead = Shizuku.OnBinderDeadListener { updateStatus() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> updateStatus() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        content = findViewById(R.id.content)
        chipsScroll = findViewById(R.id.chipsScroll)
        chips = findViewById(R.id.chips)
        scroll = findViewById(R.id.scroll)
        outputView = findViewById(R.id.output)
        input = findViewById(R.id.input)
        runBtn = findViewById(R.id.runBtn)
        statusDot = findViewById(R.id.statusDot)
        statusText = findViewById(R.id.statusText)

        ViewCompat.setOnApplyWindowInsetsListener(content) { v, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(dp(16) + i.left, dp(12) + i.top, dp(16) + i.right, dp(12) + i.bottom)
            insets
        }

        setupBackground()
        setupInteractions()
        refreshChips()
        playEntrance()

        append("Glass ADB gotowy.", C_INFO)
        append("Wpisz komendę powłoki, np. pm list packages (prefiks „adb shell” jest opcjonalny).", C_INFO)

        try {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        } catch (_: Throwable) {
        }
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        } catch (_: Throwable) {
        }
        animators.forEach { it.cancel() }
        current?.destroyForcibly()
        io.shutdownNow()
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun setupBackground() {
        if (Build.VERSION.SDK_INT >= 31) {
            findViewById<View>(R.id.blobs).setRenderEffect(
                RenderEffect.createBlurEffect(80f, 80f, Shader.TileMode.CLAMP)
            )
        }
        drift(findViewById(R.id.blob1), dp(120).toFloat(), dp(160).toFloat(), 11000, 0)
        drift(findViewById(R.id.blob2), -dp(140).toFloat(), dp(120).toFloat(), 13000, 800)
        drift(findViewById(R.id.blob3), dp(150).toFloat(), -dp(130).toFloat(), 15000, 400)
    }

    private fun drift(v: View, dx: Float, dy: Float, d: Long, delay: Long) {
        fun anim(prop: String, a: Float, b: Float) = ObjectAnimator.ofFloat(v, prop, a, b).apply {
            duration = d
            startDelay = delay
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        }
        val set = AnimatorSet()
        set.playTogether(
            anim("translationX", 0f, dx),
            anim("translationY", 0f, dy),
            anim("scaleX", 1f, 1.25f),
            anim("scaleY", 1f, 1.25f)
        )
        animators.add(set)
        set.start()
    }

    private fun playEntrance() {
        listOf(
            findViewById<View>(R.id.header), chipsScroll,
            findViewById(R.id.outputCard), findViewById(R.id.inputCard)
        ).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(40).toFloat()
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(i * 90L).setDuration(550)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressable() {
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN ->
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(240)
                        .setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    private fun setupInteractions() {
        runBtn.pressable()
        runBtn.setOnClickListener { onRunClick() }

        val copy = findViewById<TextView>(R.id.copyBtn)
        copy.pressable()
        copy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("output", synchronized(out) { out.toString() }))
            Toast.makeText(this, "Skopiowano", Toast.LENGTH_SHORT).show()
        }
        val clear = findViewById<TextView>(R.id.clearBtn)
        clear.pressable()
        clear.setOnClickListener {
            synchronized(out) { out.clear() }
            outputView.text = ""
        }

        val pill = findViewById<View>(R.id.statusPill)
        pill.pressable()
        pill.setOnClickListener { onStatusClick() }

        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) {
                onRunClick(); true
            } else false
        }
    }

    private fun refreshChips() {
        chips.removeAllViews()
        (recent + QUICK).distinct().take(16).forEach { c ->
            val tv = TextView(this).apply {
                text = c
                setTextColor(C_OUT)
                typeface = Typeface.MONOSPACE
                textSize = 12f
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setBackgroundResource(R.drawable.glass_chip)
                pressable()
                setOnClickListener {
                    input.setText(c)
                    input.setSelection(c.length)
                }
            }
            chips.addView(
                tv,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
            )
        }
    }

    // ---------- Shizuku ----------

    private fun updateStatus() {
        runOnUiThread {
            val (label, color) = when {
                ShellRunner.ready() -> "Shizuku aktywny" to 0xFF3DDC84.toInt()
                ShellRunner.running() -> "Dotknij: nadaj zgodę" to 0xFFFFC857.toInt()
                else -> "Tryb lokalny" to 0xFF8F9BB8.toInt()
            }
            statusText.text = label
            if (color != dotColor) {
                ValueAnimator.ofObject(ArgbEvaluator(), dotColor, color).apply {
                    duration = 400
                    addUpdateListener {
                        statusDot.backgroundTintList = ColorStateList.valueOf(it.animatedValue as Int)
                    }
                    start()
                }
                dotColor = color
            }
        }
    }

    private fun onStatusClick() {
        try {
            when {
                ShellRunner.ready() ->
                    Toast.makeText(this, "Shizuku połączony – komendy mają uprawnienia ADB", Toast.LENGTH_SHORT).show()
                ShellRunner.running() ->
                    if (Shizuku.shouldShowRequestPermissionRationale())
                        Toast.makeText(this, "Zgoda odrzucona – nadaj ją w aplikacji Shizuku", Toast.LENGTH_LONG).show()
                    else Shizuku.requestPermission(REQ_SHIZUKU)
                else -> {
                    val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                    if (i != null) startActivity(i)
                    else Toast.makeText(this, "Zainstaluj i uruchom Shizuku", Toast.LENGTH_LONG).show()
                }
            }
        } catch (t: Throwable) {
            Toast.makeText(this, "Błąd Shizuku: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Wykonywanie komend ----------

    private fun onRunClick() {
        if (running) {
            current?.destroyForcibly()
            append("Przerwano przez użytkownika", C_ERR)
            return
        }
        val raw = input.text.toString().trim()
        if (raw.isEmpty()) return

        var cmd = raw
        if (cmd == "adb" || cmd.startsWith("adb ")) {
            cmd = cmd.removePrefix("adb").trim()
            if (cmd == "shell" || cmd.startsWith("shell ")) {
                cmd = cmd.removePrefix("shell").trim()
            } else {
                append("$ $raw", C_PROMPT)
                append("Obsługiwane są tylko komendy powłoki (adb shell …). Wpisz np. pm list packages.", C_ERR)
                return
            }
        }
        if (cmd.isEmpty()) return

        if (RISKY.containsMatchIn(cmd)) {
            AlertDialog.Builder(this)
                .setTitle("Potencjalnie ryzykowna komenda")
                .setMessage("$cmd\n\nTa komenda może usunąć dane lub zmienić działanie telefonu. Na pewno uruchomić?")
                .setPositiveButton("Uruchom") { _, _ -> execute(raw, cmd) }
                .setNegativeButton("Anuluj", null)
                .show()
        } else {
            execute(raw, cmd)
        }
    }

    private fun execute(raw: String, cmd: String) {
        recent.remove(raw)
        recent.add(0, raw)
        refreshChips()
        input.setText("")

        val viaShizuku = ShellRunner.ready()
        append("$ $cmd", C_PROMPT)
        if (!viaShizuku && !announcedLocal) {
            announcedLocal = true
            append("(Tryb lokalny: uprawnienia zwykłej aplikacji. Włącz Shizuku, by mieć uprawnienia ADB.)", C_INFO)
        }
        setRunning(true)

        io.execute {
            var code = -1
            try {
                val p = ShellRunner.start(cmd, viaShizuku)
                current = p
                val t1 = pump(p.inputStream, C_OUT)
                val t2 = pump(p.errorStream, C_ERR)
                if (!p.waitFor(TIMEOUT_S, TimeUnit.SECONDS)) {
                    p.destroyForcibly()
                    append("Przekroczono limit ${TIMEOUT_S}s – przerwano", C_ERR)
                }
                code = try { p.exitValue() } catch (_: Throwable) { -1 }
                t1.join(1500)
                t2.join(1500)
            } catch (t: Throwable) {
                append("Błąd: ${t.cause?.message ?: t.message ?: t.javaClass.simpleName}", C_ERR)
            } finally {
                current = null
                append("[kod wyjścia: $code]", C_INFO)
                runOnUiThread { setRunning(false) }
            }
        }
    }

    private fun pump(stream: InputStream, color: Int): Thread = Thread {
        try {
            stream.bufferedReader().forEachLine { append(it, color) }
        } catch (_: Throwable) {
        }
    }.also { it.start() }

    private fun setRunning(r: Boolean) {
        running = r
        runBtn.text = if (r) "Stop" else "Uruchom"
        runBtn.setBackgroundResource(if (r) R.drawable.glass_button_stop else R.drawable.glass_button)
        runBtn.animate().scaleX(1.08f).scaleY(1.08f).setDuration(120).withEndAction {
            runBtn.animate().scaleX(1f).scaleY(1f).setDuration(220)
                .setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }

    // ---------- Wyjście (z ograniczeniem częstotliwości odświeżania) ----------

    private fun append(text: String, color: Int) {
        synchronized(out) {
            val start = out.length
            out.append(text).append('\n')
            out.setSpan(ForegroundColorSpan(color), start, out.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (out.length > 200_000) out.delete(0, out.length - 150_000)
            if (flushScheduled) return
            flushScheduled = true
        }
        ui.postDelayed({
            synchronized(out) {
                flushScheduled = false
                outputView.text = out
            }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }, 60)
    }
}
